"""
URL configuration for backend project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

API_PATH = 'api/v1'

urlpatterns = [
    path('admin/', admin.site.urls),
    path(f'{API_PATH}/accounts/', include('accounts.urls')),
    path(f'{API_PATH}/regression/', include('regression_model.urls')),
    path(f'{API_PATH}/decision-tree/', include('decision_tree.urls')),
    path(f'{API_PATH}/k-neighbors/', include('k_neighbors.urls')),
    path(f'{API_PATH}/random-forest/', include('random_forest.urls')),
    path(f'{API_PATH}/ridge-regression/', include('ridge_regression.urls')),
    path(f'{API_PATH}/trained-model/', include('trained_model.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
